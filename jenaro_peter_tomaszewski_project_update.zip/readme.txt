This spelling checker takes a 2-pronged approach
	1) Compare the word distance with words of similar length (+/- 1 letter) in the dictionary.
	2) Take the resulting word list from 1) and compare them to the misspelled word for similar letter usage keeping track of the number of letters that appear on both words.

The spelling checker uses the words used in the "Alice in Wonderland" story as the dictionary.

We created code to place the words in a dictionary of words:word length, but never rewrote the code to implemented it that way.

The user takes a paragragh from Alice.txt and places it in paragraph.txt.  Executing the code will print out a list of mispelled word and 3 possible correct words on a per line basis.

This project really makes one appreciate the value of a spelling checker/corrector and the work it takes to create one that performs well.

Our implementation has shortcomings in its ability to correct words that have a letter added or missing.  It does better at words with just a single letter incorrect.  In the latter case, we seemed to get the correct word in the 3 choices ~70% of the time.

Other functions we thought of to make better results were to check and track the similar letter locations in the word instead of just looking for the letter in the word and weighting the letter choices for incorrect letters based on the surrounding keys on the keyboard.

Another improvement would be to create the dictionary once and store it for lookup instead of creating it every time the program is run.  Over 1 second of execution time could be saved by doing this.