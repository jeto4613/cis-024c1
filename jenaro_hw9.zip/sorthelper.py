### YOUR CODE GOES BELOW
def sortNumbers(a):
    return sorted(a)

### END CODE