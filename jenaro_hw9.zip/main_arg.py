
### YOUR CODE GOES BELOW
import sys

def add(n1,n2):
    return n1+n2


print " The total is: %d" % add(int(sys.argv[1]),int(sys.argv[2]))
### END CODE