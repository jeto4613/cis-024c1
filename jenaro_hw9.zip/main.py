### YOUR CODE GOES BELOW
import argparse
import sorthelper

parser=argparse.ArgumentParser()
#parser.add_argument("n1",type=int,help="first number to sort")
parser.add_argument('userList', nargs='*', type=int)
#parser.add_argument('userList', nargs='*')


args=parser.parse_args()

print "The ascended list is as follows:%s" % sorthelper.sortNumbers(args.userList)

    
### END CODE